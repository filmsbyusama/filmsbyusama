const express = require('express');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Data file paths ───────────────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, 'data');
const MEDIA_FILE = path.join(DATA_DIR, 'media.json');
const CLIENTS_FILE = path.join(DATA_DIR, 'clients.json');
const CONTENT_FILE = path.join(DATA_DIR, 'content.json');

// Ensure data dir + files exist
fs.ensureDirSync(DATA_DIR);
if (!fs.existsSync(MEDIA_FILE)) fs.writeJsonSync(MEDIA_FILE, { photos: [], videos: [] });
if (!fs.existsSync(CLIENTS_FILE)) fs.writeJsonSync(CLIENTS_FILE, []);
if (!fs.existsSync(CONTENT_FILE)) {
  fs.writeJsonSync(CONTENT_FILE, {
    heroTitle: "Timeless Stories,\nBeautifully Told",
    heroSubtitle: "Wedding Photography & Cinematography",
    aboutText: "We are Usama & team — visual storytellers based in Lahore, Pakistan. We believe every wedding is a universe of fleeting moments, and our mission is to preserve them with grace, artistry, and emotion.",
    aboutImage: "",
    email: "hello@filmsbyusama.com",
    phone: "+92 300 0000000",
    whatsapp: "923000000000",
    instagram: "https://instagram.com/filmsbyusama",
    facebook: "https://facebook.com/filmsbyusama",
    youtube: "https://youtube.com/@filmsbyusama"
  });
}

// ─── Admin credentials (hashed) ───────────────────────────────────────────
const ADMIN = {
  username: 'admin',
  // password: filmsbyusama2024
  passwordHash: bcrypt.hashSync('filmsbyusama2024', 10)
};

// ─── Multer storage ────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const isVideo = file.mimetype.startsWith('video/');
    const dest = path.join(__dirname, 'public/uploads', isVideo ? 'videos' : 'photos');
    fs.ensureDirSync(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 200 * 1024 * 1024 } });

// ─── Middleware ────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'filmsbyusama_secret_key_2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// Auth middleware
const requireAuth = (req, res, next) => {
  if (req.session.admin) return next();
  res.redirect('/admin/login');
};

// ─── Helper functions ──────────────────────────────────────────────────────
const readMedia = () => fs.readJsonSync(MEDIA_FILE);
const writeMedia = (data) => fs.writeJsonSync(MEDIA_FILE, data, { spaces: 2 });
const readClients = () => fs.readJsonSync(CLIENTS_FILE);
const writeClients = (data) => fs.writeJsonSync(CLIENTS_FILE, data, { spaces: 2 });
const readContent = () => fs.readJsonSync(CONTENT_FILE);
const writeContent = (data) => fs.writeJsonSync(CONTENT_FILE, data, { spaces: 2 });

// ════════════════════════════════════════════════════════════════
// PUBLIC ROUTES
// ════════════════════════════════════════════════════════════════

app.get('/', (req, res) => {
  const media = readMedia();
  const content = readContent();
  res.render('index', { media, content });
});

app.get('/portfolio', (req, res) => {
  const media = readMedia();
  const content = readContent();
  res.render('portfolio', { media, content });
});

app.get('/storybook', (req, res) => {
  const media = readMedia();
  const content = readContent();
  const storybook = media.photos.filter(p => p.storybook);
  res.render('storybook', { storybook, content });
});

app.get('/about', (req, res) => {
  const content = readContent();
  res.render('about', { content });
});

app.get('/contact', (req, res) => {
  const content = readContent();
  res.render('contact', { content });
});

// Client portal
app.get('/client', (req, res) => {
  const content = readContent();
  res.render('client-login', { content, error: null });
});

app.post('/client/login', (req, res) => {
  const { code } = req.body;
  const clients = readClients();
  const client = clients.find(c => c.code === code);
  if (!client) {
    const content = readContent();
    return res.render('client-login', { content, error: 'Invalid access code. Please check with your photographer.' });
  }
  req.session.clientId = client.id;
  res.redirect('/client/portal');
});

app.get('/client/portal', (req, res) => {
  if (!req.session.clientId) return res.redirect('/client');
  const clients = readClients();
  const client = clients.find(c => c.id === req.session.clientId);
  if (!client) return res.redirect('/client');
  const content = readContent();
  res.render('client-portal', { client, content });
});

app.post('/client/select-photos', (req, res) => {
  if (!req.session.clientId) return res.status(401).json({ error: 'Unauthorized' });
  const { photoIds } = req.body;
  const clients = readClients();
  const idx = clients.findIndex(c => c.id === req.session.clientId);
  if (idx === -1) return res.status(404).json({ error: 'Client not found' });
  clients[idx].selectedPhotos = photoIds;
  clients[idx].updatedAt = new Date().toISOString();
  writeClients(clients);
  res.json({ success: true });
});

app.post('/client/select-song', (req, res) => {
  if (!req.session.clientId) return res.status(401).json({ error: 'Unauthorized' });
  const { song, artist, note } = req.body;
  const clients = readClients();
  const idx = clients.findIndex(c => c.id === req.session.clientId);
  if (idx === -1) return res.status(404).json({ error: 'Client not found' });
  clients[idx].songChoice = { song, artist, note };
  clients[idx].updatedAt = new Date().toISOString();
  writeClients(clients);
  res.json({ success: true });
});

app.get('/client/logout', (req, res) => {
  req.session.clientId = null;
  res.redirect('/client');
});

// Contact form submission
app.post('/contact/send', (req, res) => {
  const { name, email, phone, date, message } = req.body;
  // In production: send email via nodemailer
  // For demo: just return success
  res.json({ success: true, message: 'Message received! We will contact you shortly.' });
});

// ════════════════════════════════════════════════════════════════
// ADMIN ROUTES
// ════════════════════════════════════════════════════════════════

app.get('/admin/login', (req, res) => {
  if (req.session.admin) return res.redirect('/admin');
  res.render('admin/login', { error: null });
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN.username && bcrypt.compareSync(password, ADMIN.passwordHash)) {
    req.session.admin = true;
    return res.redirect('/admin');
  }
  res.render('admin/login', { error: 'Invalid credentials' });
});

app.get('/admin/logout', (req, res) => {
  req.session.admin = false;
  res.redirect('/admin/login');
});

app.get('/admin', requireAuth, (req, res) => {
  const media = readMedia();
  const clients = readClients();
  res.render('admin/dashboard', {
    photoCount: media.photos.length,
    videoCount: media.videos.length,
    clientCount: clients.length
  });
});

// Media management
app.get('/admin/media', requireAuth, (req, res) => {
  const media = readMedia();
  res.render('admin/media', { media });
});

app.post('/admin/upload', requireAuth, upload.single('file'), (req, res) => {
  const { title, category, storybook, type } = req.body;
  const media = readMedia();
  const item = {
    id: uuidv4(),
    title: title || 'Untitled',
    category: category || 'Wedding',
    storybook: storybook === 'on',
    filename: req.file.filename,
    originalName: req.file.originalname,
    mimetype: req.file.mimetype,
    size: req.file.size,
    uploadedAt: new Date().toISOString()
  };
  const isVideo = req.file.mimetype.startsWith('video/');
  if (isVideo) {
    item.thumbnail = req.body.thumbnail || '';
    media.videos.push(item);
  } else {
    media.photos.push(item);
  }
  writeMedia(media);
  res.json({ success: true, item });
});

app.delete('/admin/media/:type/:id', requireAuth, (req, res) => {
  const { type, id } = req.params;
  const media = readMedia();
  const arr = type === 'video' ? media.videos : media.photos;
  const idx = arr.findIndex(i => i.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  const item = arr[idx];
  const folder = type === 'video' ? 'videos' : 'photos';
  const filePath = path.join(__dirname, 'public/uploads', folder, item.filename);
  if (fs.existsSync(filePath)) fs.removeSync(filePath);
  arr.splice(idx, 1);
  writeMedia(media);
  res.json({ success: true });
});

app.put('/admin/media/:type/:id', requireAuth, (req, res) => {
  const { type, id } = req.params;
  const { title, category, storybook } = req.body;
  const media = readMedia();
  const arr = type === 'video' ? media.videos : media.photos;
  const item = arr.find(i => i.id === id);
  if (!item) return res.status(404).json({ error: 'Not found' });
  item.title = title || item.title;
  item.category = category || item.category;
  item.storybook = storybook === true || storybook === 'true';
  writeMedia(media);
  res.json({ success: true, item });
});

// Client management
app.get('/admin/clients', requireAuth, (req, res) => {
  const clients = readClients();
  const media = readMedia();
  res.render('admin/clients', { clients, media });
});

app.post('/admin/clients/add', requireAuth, (req, res) => {
  const { name, email, weddingDate, code } = req.body;
  const clients = readClients();
  if (clients.find(c => c.code === code)) {
    return res.json({ error: 'Code already exists' });
  }
  const client = {
    id: uuidv4(),
    name, email, weddingDate,
    code,
    photoPool: [],
    selectedPhotos: [],
    songChoice: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  clients.push(client);
  writeClients(clients);
  res.json({ success: true, client });
});

app.put('/admin/clients/:id/photos', requireAuth, (req, res) => {
  const { photoIds } = req.body;
  const clients = readClients();
  const client = clients.find(c => c.id === req.params.id);
  if (!client) return res.status(404).json({ error: 'Not found' });
  client.photoPool = photoIds;
  client.updatedAt = new Date().toISOString();
  writeClients(clients);
  res.json({ success: true });
});

app.delete('/admin/clients/:id', requireAuth, (req, res) => {
  const clients = readClients();
  const idx = clients.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  clients.splice(idx, 1);
  writeClients(clients);
  res.json({ success: true });
});

// Content management
app.get('/admin/content', requireAuth, (req, res) => {
  const content = readContent();
  res.render('admin/content', { content, saved: false });
});

app.post('/admin/content', requireAuth, upload.single('aboutImage'), (req, res) => {
  const content = readContent();
  const { heroTitle, heroSubtitle, aboutText, email, phone, whatsapp, instagram, facebook, youtube } = req.body;
  Object.assign(content, { heroTitle, heroSubtitle, aboutText, email, phone, whatsapp, instagram, facebook, youtube });
  if (req.file) content.aboutImage = `/uploads/photos/${req.file.filename}`;
  writeContent(content);
  res.render('admin/content', { content, saved: true });
});

// ─── Start server ──────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🎬 filmsbyusama running at http://localhost:${PORT}`);
  console.log(`🔐 Admin panel: http://localhost:${PORT}/admin`);
  console.log(`   Username: admin | Password: filmsbyusama2024\n`);
});
