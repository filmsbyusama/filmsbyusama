# filmsbyusama — Complete Wedding Portfolio Website
## Setup, Admin Guide & Deployment Instructions

---

## 🔐 Admin Login Credentials

| Field    | Value              |
|----------|--------------------|
| URL      | /admin             |
| Username | admin              |
| Password | filmsbyusama2024   |

> **Change the password** by editing `server.js` line 27:
> Replace `'filmsbyusama2024'` with your new password.

---

## 📁 Folder Structure

```
filmsbyusama/
├── server.js              ← Main backend (Node.js + Express)
├── package.json           ← Dependencies
├── data/
│   ├── media.json         ← Photos & videos database
│   ├── clients.json       ← Client accounts database
│   └── content.json       ← Website text & links
├── public/
│   ├── css/
│   │   ├── style.css      ← Main website styles
│   │   └── admin.css      ← Admin panel styles
│   ├── js/
│   │   └── main.js        ← Frontend JavaScript
│   └── uploads/
│       ├── photos/        ← Uploaded photos stored here
│       └── videos/        ← Uploaded videos stored here
└── views/
    ├── index.ejs          ← Homepage
    ├── portfolio.ejs      ← Portfolio page
    ├── storybook.ejs      ← Storybook album
    ├── about.ejs          ← About page
    ├── contact.ejs        ← Contact page
    ├── client-login.ejs   ← Client portal login
    ├── client-portal.ejs  ← Client portal (select photos + music)
    ├── partials/
    │   ├── header.ejs     ← Nav + lightbox (shared)
    │   └── footer.ejs     ← Footer (shared)
    └── admin/
        ├── login.ejs      ← Admin login
        ├── dashboard.ejs  ← Admin home
        ├── media.ejs      ← Upload/delete/edit media
        ├── clients.ejs    ← Manage client portals
        ├── content.ejs    ← Edit site text & images
        └── partials/
            ├── layout-top.ejs
            └── layout-bottom.ejs
```

---

## 🚀 Local Setup (First Time)

```bash
# 1. Go into project folder
cd filmsbyusama

# 2. Install dependencies
npm install

# 3. Start the server
npm start
# or for development (auto-restarts on changes):
npm run dev

# 4. Open in browser
http://localhost:3000        ← Website
http://localhost:3000/admin  ← Admin Panel
```

---

## 🌐 Deployment Guide

### ✅ RECOMMENDED: Hostinger VPS or Business Hosting

Hostinger supports Node.js and is the best option for this full-stack app.

#### Step-by-step:

1. **Buy a Hostinger plan** — Business Shared or VPS (VPS recommended for media uploads)

2. **Upload your files** via hPanel File Manager or FTP:
   - Upload the entire `filmsbyusama/` folder to `public_html/` or a subdirectory

3. **Install Node.js** (on VPS):
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

4. **Install dependencies on server**:
   ```bash
   cd /path/to/filmsbyusama
   npm install --production
   ```

5. **Set up PM2** (keeps the app running 24/7):
   ```bash
   npm install -g pm2
   pm2 start server.js --name filmsbyusama
   pm2 save
   pm2 startup
   ```

6. **Configure Nginx** (reverse proxy) on VPS:
   ```nginx
   server {
     server_name yourdomain.com www.yourdomain.com;
     location / {
       proxy_pass http://localhost:3000;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_cache_bypass $http_upgrade;
       client_max_body_size 200M;
     }
   }
   ```

7. **Enable HTTPS** with Let's Encrypt:
   ```bash
   sudo certbot --nginx -d yourdomain.com
   ```

---

### 🟡 Alternative: Railway.app (Easy Cloud Deploy)

1. Create a free account at railway.app
2. Connect your GitHub repo
3. Railway auto-detects Node.js and deploys
4. Set environment variable: `PORT=3000`
5. Add a persistent volume for `public/uploads/` and `data/`

---

### ❌ Netlify — NOT recommended
Netlify is for static sites only. This app has a Node.js backend, so Netlify won't work for uploads, admin panel, or client portals.

---

## 📸 How to Update Content (No Coding Needed)

### Upload Photos/Videos
1. Go to `/admin` → Login
2. Click **Media Library** → **Upload New**
3. Drag & drop your file, set title + category
4. Check "Storybook" to feature it on the Storybook page

### Edit Website Text
1. Go to `/admin` → **Site Content**
2. Edit Hero title, About text, contact info, social links
3. Click **Save All Changes**

### Add a Client Portal
1. Go to `/admin` → **Clients** → **Add Client**
2. Enter their name, wedding date, and create a unique code (e.g. `HIRA2024`)
3. Share the code with the client — they log in at `/client`
4. Click **Photos** to assign which photos they can see and select

### View Client Selections
1. Go to `/admin` → **Clients**
2. Click **View** on any client to see:
   - How many photos they selected
   - Their music/song choice
   - Any notes they left

---

## 🎨 Customization Tips

### Change Brand Colors
Edit `public/css/style.css`, find `:root {` and change:
```css
--accent: #b8914a;   /* Main gold color */
--accent2: #d4a96a;  /* Lighter gold */
```

### Change Fonts
In `views/partials/header.ejs`, replace the Google Fonts import URL with any other font from fonts.google.com

### Add Your Logo
Replace the text logo in `views/partials/header.ejs`:
```html
<a href="/" class="nav-logo">films<span>by</span>usama</a>
```

### Add More Testimonials
In `views/index.ejs`, find the `testimonial-track` div and add more `.testimonial-slide` blocks.

---

## 🔒 Security Notes

1. Change the default admin password before going live
2. Keep `data/` folder outside `public/` (already done)
3. For production, set `NODE_ENV=production` environment variable
4. Consider adding rate limiting to the contact form endpoint

---

## 📧 Enable Real Email (Contact Form)

Currently the contact form returns a success message without sending email.
To enable real emails, install nodemailer:

```bash
npm install nodemailer
```

Then in `server.js`, replace the `/contact/send` route handler with:
```javascript
const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: 'you@gmail.com', pass: 'your-app-password' }
});
// then: await transporter.sendMail({...})
```

---

*filmsbyusama © 2024 — Built with Node.js + Express + EJS*
