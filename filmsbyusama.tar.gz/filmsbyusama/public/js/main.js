/* filmsbyusama — Main JS */

// ─── Theme Toggle ─────────────────────────────────
const savedTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', savedTheme);

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  updateThemeIcon();
}

function updateThemeIcon() {
  const theme = document.documentElement.getAttribute('data-theme');
  const icons = document.querySelectorAll('.theme-icon');
  icons.forEach(icon => {
    icon.innerHTML = theme === 'dark'
      ? `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`
      : `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`;
  });
}

// ─── Navigation ───────────────────────────────────
const nav = document.querySelector('nav');
if (nav) {
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 50);
  });
}

// Hamburger menu
const hamburger = document.querySelector('.hamburger');
const mobileMenu = document.querySelector('.mobile-menu');

if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    const open = mobileMenu.classList.toggle('open');
    hamburger.querySelectorAll('span')[0].style.transform = open ? 'rotate(45deg) translate(5px, 5px)' : '';
    hamburger.querySelectorAll('span')[1].style.opacity = open ? '0' : '1';
    hamburger.querySelectorAll('span')[2].style.transform = open ? 'rotate(-45deg) translate(5px, -5px)' : '';
    document.body.style.overflow = open ? 'hidden' : '';
  });

  mobileMenu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      document.body.style.overflow = '';
    });
  });
}

// Active nav link
const currentPath = window.location.pathname;
document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(a => {
  if (a.getAttribute('href') === currentPath) a.classList.add('active');
});

// ─── Scroll Animations ────────────────────────────
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => {
        entry.target.classList.add('visible');
      }, entry.target.dataset.delay || 0);
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

document.querySelectorAll('.fade-up, .fade-in').forEach((el, i) => {
  if (el.closest('.stagger')) {
    el.style.setProperty('--i', i % 6);
  }
  observer.observe(el);
});

// ─── Lightbox ─────────────────────────────────────
let lightboxImages = [];
let lightboxIndex = 0;
const lightbox = document.getElementById('lightbox');

function openLightbox(src, type, items, index) {
  if (!lightbox) return;
  lightboxImages = items || [{ src, type }];
  lightboxIndex = index || 0;
  renderLightboxItem();
  lightbox.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  if (!lightbox) return;
  lightbox.classList.remove('open');
  document.body.style.overflow = '';
  const vid = lightbox.querySelector('video');
  if (vid) vid.pause();
}

function renderLightboxItem() {
  const container = document.getElementById('lightbox-content');
  if (!container) return;
  const item = lightboxImages[lightboxIndex];
  if (item.type === 'video') {
    container.innerHTML = `<video controls autoplay style="max-width:90vw;max-height:80vh"><source src="${item.src}"></video>`;
  } else {
    container.innerHTML = `<img src="${item.src}" style="max-width:90vw;max-height:85vh;object-fit:contain" alt="">`;
  }
  const nav = document.getElementById('lightbox-nav-info');
  if (nav) nav.textContent = `${lightboxIndex + 1} / ${lightboxImages.length}`;
}

function lightboxPrev() {
  lightboxIndex = (lightboxIndex - 1 + lightboxImages.length) % lightboxImages.length;
  renderLightboxItem();
}

function lightboxNext() {
  lightboxIndex = (lightboxIndex + 1) % lightboxImages.length;
  renderLightboxItem();
}

if (lightbox) {
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) closeLightbox();
  });
  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') lightboxPrev();
    if (e.key === 'ArrowRight') lightboxNext();
  });
}

// Attach to all media cards
function initLightbox() {
  const cards = document.querySelectorAll('[data-lightbox]');
  const items = [];
  cards.forEach((card, i) => {
    items.push({ src: card.dataset.src, type: card.dataset.type || 'photo' });
    card.addEventListener('click', () => openLightbox(card.dataset.src, card.dataset.type || 'photo', items, i));
    card.style.cursor = 'pointer';
  });
}

// ─── Testimonial Slider ───────────────────────────
function initTestimonials() {
  const track = document.querySelector('.testimonial-track');
  const dots = document.querySelectorAll('.dot');
  if (!track || !dots.length) return;

  let current = 0;
  const total = dots.length;

  function go(n) {
    current = (n + total) % total;
    track.style.transform = `translateX(-${current * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === current));
  }

  dots.forEach((dot, i) => dot.addEventListener('click', () => go(i)));
  go(0);
  setInterval(() => go(current + 1), 5000);
}

// ─── Contact Form ─────────────────────────────────
const contactForm = document.getElementById('contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('button[type=submit]');
    btn.disabled = true;
    btn.textContent = 'Sending...';
    const data = Object.fromEntries(new FormData(contactForm));
    try {
      const res = await fetch('/contact/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await res.json();
      showToast(result.message, 'success');
      contactForm.reset();
    } catch (err) {
      showToast('Something went wrong. Please try again.', 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Send Message';
    }
  });
}

// ─── Toast ────────────────────────────────────────
function showToast(msg, type = '') {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  setTimeout(() => toast.classList.remove('show'), 4000);
}

// ─── Photo selector (client portal) ──────────────
function initPhotoSelector() {
  const items = document.querySelectorAll('.photo-select-item');
  const counter = document.getElementById('selection-count');
  const bar = document.querySelector('.selection-bar');
  const saveBtn = document.getElementById('save-photos');
  const selected = new Set();

  items.forEach(item => {
    item.addEventListener('click', () => {
      const id = item.dataset.id;
      if (selected.has(id)) {
        selected.delete(id);
        item.classList.remove('selected');
      } else {
        selected.add(id);
        item.classList.add('selected');
      }
      if (counter) counter.textContent = selected.size;
      if (bar) bar.classList.toggle('visible', selected.size > 0);
    });
  });

  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      try {
        const res = await fetch('/client/select-photos', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ photoIds: [...selected] })
        });
        const result = await res.json();
        if (result.success) showToast('Photo selections saved!', 'success');
      } catch { showToast('Could not save. Try again.', 'error'); }
    });
  }
}

// Song form
const songForm = document.getElementById('song-form');
if (songForm) {
  songForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(songForm));
    try {
      const res = await fetch('/client/select-song', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await res.json();
      if (result.success) showToast('Song preference saved!', 'success');
    } catch { showToast('Could not save. Try again.', 'error'); }
  });
}

// ─── Portal tabs ──────────────────────────────────
document.querySelectorAll('.portal-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const target = tab.dataset.tab;
    document.querySelectorAll('.portal-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.portal-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`panel-${target}`)?.classList.add('active');
  });
});

// ─── Init ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateThemeIcon();
  initLightbox();
  initTestimonials();
  initPhotoSelector();

  // Hero parallax
  const heroBg = document.querySelector('.hero-bg');
  if (heroBg) {
    window.addEventListener('scroll', () => {
      heroBg.style.transform = `scale(1.05) translateY(${window.scrollY * 0.15}px)`;
    });
  }
});
